﻿<?php 

function getCn(){	
	static $cn;
	if(!$cn) $cn= new PDO("mysql:host=localhost;dbname=doctor", "root", "");
	return $cn;
}



function validemailpass($email,$pas) {
	$Rq= getCn()->prepare("SELECT count(*) from patient where email=? and password = ?");
	$Rq->execute([$email,$pas]);
	if($Rq->fetchColumn()){
	return true;
	}
	return false;
}

function insertion($email,$nom,$prenom,$password,$telephone){
	global $cn;
	$req=getCn()->prepare("INSERT INTO patient(Prenom, Nom, email, password , telephone) VALUES (?,?,?,?,?);");
	$req->execute([$prenom,$nom,$email,$password,$telephone]);
}

function dataconnecte($user){
	return getCn()->query("SELECT * from patient where email='$user' ")->fetch();
}
function docconnecte($id){
	return getCn()->query("SELECT * from dentiste where id='$id' ")->fetch();
}
