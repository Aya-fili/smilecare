<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

include "Library.php";
include "Controller.php";
try {
	session_start();
	$action=$_GET["action"] ?? "index";
	$action = getRoute();
	$action();
}catch (Exception $e) {
  afficher("vError.php",["errorMessage"=> $e->getMessage()]);
}