
<!DOCTYPE html>
<html lang="en"> 
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="views/ajout.css">
	<link rel="shortcut icon" href="views/img/dent.png">
	<title>Formulaire</title>
<div class="container">
</head>
<html>
	<body>
		<form class= "form2" action= "" method="post" >
		
	<div class="txt">
			<p>Bienvenue</p>
			<input type="text" placeholder="Entrer le prenom" name="prenom"> <span class="Err"><?= $erreur["prenom"] ?? "" ?> </span><br>
			<input type="text" placeholder="Entrer le nom" name="nom"> <span class="Err"><?= $erreur["nom"] ?? "" ?> </span><br>
			<input type="email" placeholder="Enter your email" name="email"> <span class="Err"><?= $erreur["email"] ?? "" ?> </span><br>
			<input type="password" placeholder="Enter your password" name="password"> <span class="Err"><?= $erreur["password"] ?? "" ?> </span><br>
			<input type="tel" placeholder="Entrer ton telephone" name="telephone"> <span class="Err"><?= $erreur["telephone"] ?? "" ?> </span><br>
	</div>
	<input type="submit" value="Enregistrer" name="submit">  <input type="reset" value="Annuler" name="Reset" >
	<div class="acc">
	<a href="index.php?action=authentifier">S'authentifier</a>
	<br>
	<!--<a href="page.php">Revenir à l'acceuil</a>-->
	</div>					
	</form>
	</body>
</html>



