<!DOCTYPE html>
<html lang="en"> 
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>SmileCare</title>
	<link rel="stylesheet" href="views/css/font-awesome.min.css">
	<link rel="stylesheet" href="views/css/sign-in.css">

	<link rel="stylesheet" href="views/css/bootstrap.min.css">
	<link rel="stylesheet" href="views/css/style.css">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,800,700,300' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=BenchNine:300,400,700' rel='stylesheet' type='text/css'>
	<script src="views/js/modernizr.js"></script>
	<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
	<link rel="shortcut icon" href="views/img/dent.png">

</head>
<body>
	
	<!-- ====================================================
	header section -->
	<header class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-xs-5 header-logo">
					<br>
					<a href="index.php"><img src="views/img/1.png" alt="" class="img-responsive logo"></a>
				</div>

				<div class="col-md-7">
					<nav class="navbar navbar-default">
					  <div class="container-fluid nav-bar">
					    <!-- Brand and toggle get grouped for better mobile display -->
					    <div class="navbar-header">
					      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					        <span class="sr-only">Toggle navigation</span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					      </button>
					    </div>

					    <!-- Collect the nav links, forms, and other content for toggling -->
					    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					      
					      <ul class="nav navbar-nav navbar-right">
					        <li><a class="menu active" href="#home" >Acceuil</a></li>
					        <li><a class="menu" href="#about">A propos</a></li>
					        <li><a class="menu" href="#service">Nos services </a></li>
					        <li><a class="menu" href="#team">Notre équipe</a></li>
							<?php if(!isset($_SESSION["user"])){?>
					        <li><a class="menu" href="index.php?action=authentifier">se connecter</a></li>
                            <?php }else{?>
								<li><a class="menu" href="index.php?action=deconnexion"> deconnexion</a></li>
								<?php }?>
					      </ul>
					    </div><!-- /navbar-collapse -->
					  </div><!-- / .container-fluid -->
					</nav>
				</div>
			</div>
		</div>
	</header> <!-- end of header area -->

	<section class="slider" id="home">
		<div class="container-fluid">
			<div class="row">
			    <div id="carouselHacked" class="carousel slide carousel-fade" data-ride="carousel">
					<div class="header-backup"></div>
			        <!-- Wrapper for slides -->
			        <div class="carousel-inner" role="listbox">
			            <div class="item active">
			            	<img src="views/img/s1.jpg" alt="">
			                <div class="carousel-caption">
		               			<h1>Offrant</h1>
		               			<p>les meilleurs services dentaires</p>
		               			<button><a href="#team">Chercher un dentiste</a></button>
			                </div>
			            </div>
			            
			            
			        <!-- Controls -->
			        
					
			            <span class="sr-only">Previous</span>
			        </a>
			    
			            <span class="sr-only">Next</span>
			        </a>
			    </div>
			</div>
		</div>
	</section><!-- end of slider section -->

	<!-- about section -->
	<section class="about text-center" id="about">
		<div class="container">
			<div class="row">
				<h2>A propos</h2>
				<h4>SmileCare est un service en ligne gratuit disponible 24h/24,7j/7 qui Vous permet de trouver le chirurgien dentiste ou le dentiste dont vous en avez besoin au moment que vous en avez besoin</h4>
				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail clearfix">
						<div class="about-img">
							<img class="img-responsive" src="views/img/1.jpg" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>c</h1>
							</div>
							<h3>Chirurgie dentaire</h3>
							<p>Profitez de la meilleure chirurgie avec nos specialistes .</p>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail">
						<div class="about-img">
							<img class="img-responsive" src="views/img/2.jpg" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>B</h1>
							</div>

							<h3>Blanchiment</h3>
							<p>Optez d'un merveilleux sourire avec SmileCare.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail">
						<div class="about-img">
							<img class="img-responsive" src="views/img/33.jpg" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>A</h1>
							</div>
							<h3>Appareil dentaire</h3>
							<p> corriger les dents mal positionnées , les décalages entre les mâchoires </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section><!-- end of about section -->


	<!-- service section starts here -->
	<section class="service text-center" id="service">
		<div class="container">
			<div class="row">
				<h2>Nos services</h2>
				<h4>Profitez de nos services tout au long de la semaine sauf les dimanches</h4>
				<div class="col-md-3 col-sm-6">
					<div class="single-service">
						<div class="single-service-img">
							<div class="service-img">
								<img class="heart img-responsive" src="views/img/ser1-removebg-preview.png" alt="">
							</div>
						</div>
						<h3>Orthodontiste</h3>
					</div>
				</div>
				<div class="col-md-3 col-sm-6">
					<div class="single-service">
						<div class="single-service-img">
							<div class="service-img">
								<img class="brain img-responsive" src="views/img/service_2-removebg-preview.png" alt="">
							</div>
						</div>
						<h3>Parodontiste</h3>
					</div>
				</div>
				<div class="col-md-3 col-sm-6">
					<div class="single-service">
						<div class="single-service-img">
							<div class="service-img">
								<img class="knee img-responsive" src="views/img/service_3-removebg-preview.png" alt="">
							</div>
						</div>
						<h3>Pedodontiste</h3>
					</div>
				</div>
				<div class="col-md-3 col-sm-6">
					<div class="single-service">
						<div class="single-service-img">
							<div class="service-img">
								<img class="bone img-responsive" src="views/img/service4.png" alt="">
							</div>
						</div>
						<h3>Dentiste chirurgien</h3>
					</div>
				</div>
			</div>
		</div>
	</section><!-- end of service section -->


	<!-- team section -->
	<section class="team" id="team">
		<div class="container">
			<div class="row">
				<div class="team-heading text-center">
					<h2>Nos dentistes</h2>
					<h4>Le dentiste traite toutes les maladies des dents, des gencives et de la mâchoire, ainsi que des diagnostics et fournit un traitement approprié.</h4>
				</div>
				<div class="col-md-2 single-member col-sm-4">
					<div class="person">
						<img class="img-responsive" src="views/img/doc22.jpg" alt="member-1">
					</div>
					<div class="person-detail">
						<div class="arrow-bottom"></div>
						<h3>Dr Mohamed Tazi</h3>
						<p>Esthétique dentaire, Dentiste, Orthodontiste
Adresse:3 A, Lotiss. Mabrouka, Av. Mohammed Vi, 2°ét. n°19 , Hay Badr,
en Face café SIX, Fès, 30000, Maroc </p>
						<button><a href="index.php?action=rendez&route=rv&id=1">Rendez-vous</a></button>
					</div>
				</div>
				<div class="col-md-2 single-member col-sm-4">
					<div class="person-detail">
						<div class="arrow-top"></div>
						<h3>Dr El Mehdi Cherrate</h3>
						<p>Esthétique dentaire, Dentiste, Implantologiste , Chirurgie buccale, Orthodontiste, Pédodontiste
						Adresse:Hay Saada, Près De Mosquée Attakoua </p>
						<button><a href="index.php?action=rendez&route=rv&id=2">Rendez-vous</a></button>
					</div>
					<div class="person">
						<img class="img-responsive" src="views/img/doc1.jpg" alt="member-2">
					</div>
				</div>
				<div class="col-md-2 single-member col-sm-4">
					<div class="person">
						<img class="img-responsive" src="views/img/doc3.png" alt="member-3">
					</div>
					<div class="person-detail">
						<div class="arrow-bottom"></div>
						<h3>Dr Ghita Sossey Alaoui.</h3>
						<p>Dentiste, Esthétique dentaire, Orthodontiste, Pédodontiste
						.<br>Adresse:Rue Matran Khalil Matran Résidence Noor Fes, Maroc. </p>
						<button><a href="index.php?action=rendez&route=rv&id=3">Rendez-vous</a></button>
					</div>
				</div>
				<div class="col-md-2 single-member col-sm-4">
					<div class="person-detail">
						<div class="arrow-top"></div>
						<h3>Dr Wijdane Elhajjaji.</h3>
						<p>Esthétique dentaire, Dentiste, Endodontiste, Implantologiste , Chirurgie buccale, Orthodontiste, Pédodontiste,Parodontologiste.<br>Adresse:Bureau 7, Etage1,Makatib Manarat Fès,Avenue Lalla Aicha.</p>
						<button><a href="index.php?action=rendez&route=rv&id=4">Rendez-vous</a></button>
					</div>
					<div class="person">
						<img class="img-responsive" src="views/img/doc4.jpg" alt="member-4">
					</div>
				</div>
				<div class="col-md-2 single-member col-sm-4">
					<div class="person">
						<img class="img-responsive" src="views/img/doc5.jpg" alt="member-5">
					</div>
					<div class="person-detail">
						<div class="arrow-bottom"></div>
						<h3>Dr Otman Bellamine</h3>
						<p>Esthétique dentaire, Dentiste, Orthodontiste, Pédodontiste à Fès.<br>Adresse:5 Ave Allal Ben Abdellah, 5 ème étage Résidence Al Youbia, Avenue Allal Ben Abdellah,
à côté de café Lost, Fès, 30000, Maroc </p>
						<button><a href="index.php?action=rendez&route=rv&id=5">Rendez-vous</a></button>
					</div>
				</div>
				<div class="col-md-2 single-member col-sm-4">
					<div class="person-detail">
						<div class="arrow-top"></div>
						<h3>Dr Chaymae Sebti.</h3>
						<p>Esthétique dentaire, Dentiste, Implantologiste , Orthodontiste à Fès 
							Adresse:10, Av Des Far Bureaux Noor,, 1er Etage, Appt 1, (Au Dessous De Biougnach), Fès, 30010, Maroc, </p>
						<button><a href="index.php?action=rendez&route=rv&id=6">Rendez-vous</a></button>
					</div>
					<div class="person">
						<img class="img-responsive" src="views/img/doc6.jpg" alt="member-5">
					</div>
				</div>
			</div>
		</div>
	</section><!-- end of team section -->

	<!-- map section -->
	<div class="api-map" id="contact">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12 map" id="map"></div>
			</div>
		</div>
	</div><!-- end of map section -->

	<!-- contact section starts here -->
	<section class="contact">
		<div class="container">
			<div class="row">
				<div class="contact-caption clearfix">
					<div class="contact-heading text-center">
						<h2>contactez-nous</h2>
					</div>
					<div class="col-md-5 contact-info text-left">
						<h3>contact information</h3>
						<div class="info-detail">
							<ul><li><i class="fa fa-calendar"></i><span>Lundi - Vendredi:</span> 9h jusqu'à 17h</li></ul>
							<ul><li><i class="fa fa-map-marker"></i><span>Adresse:</span>centre ville Fes</li></ul>
							<ul><li><i class="fa fa-phone"></i><span>Télépone:</span> 0684717014</li></ul>
							<ul><li><i class="fa fa-envelope"></i><span>Email:</span> SmileCare@gmail.com</li></ul>
						</div>
					</div>
					
	</section><!-- end of contact section -->

	<!-- footer starts here -->
	<footer class="footer "  style="background-color:#328eb9">
		<div class="container" >
			<div class="row">
				<div class="col-xs-6 footer-para">
					<p style="color:white">&copy;SmileCare All right reserved</p>
				</div>
<style>

.header-logo{
margin-left: -30px;	
margin-top: 20px;
}
.navbar-default .navbar-nav>li>a {
    
    font-size: 25px;
    color: #328eb9;
    text-transform: uppercase;
    transition: all .7s ease 0s;
    -webkit-transition: all .7s ease 0s;
    -moz-transition: all .7s ease 0s;
    -o-transition: all .7s ease 0s;
    -ms-transition: all .7s ease 0s;
    padding: 14px 10px;
    font-weight: bold;
}
.footer a i.fa {
    font-size: 24px;
    color: blanchedalmond;
    padding: 22px 10px;
}
    .footer a i.fa:hover {
    color: #42b3e5;
}
  </style>
				<div class="col-xs-6 text-right">
					<a href=""><i class="fa fa-facebook"></i></a>
					<a href=""><i class="fa fa-envelope"></i></a>
					<a href=""><i class="fa fa-linkedin"></i></a>
				</div>
			</div>
		</div>
	</footer>
<!-- script tags
	============================================================= essayer de retirer ces files de js -->
	<script src="js/jquery-2.1.1.js"></script>
	<script src="js/gmaps.js"></script>
	<script src="js/smoothscroll.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/custom.js"></script>
	
</body>
</html>