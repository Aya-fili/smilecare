<!DOCTYPE html>
<html lang="en"> 
<head>
	
    <link rel="stylesheet" href="views/form.css">
    <link rel="shortcut icon" href="views/img/dent.png">
<div class="container"> 
</head>
<body>
    
      <p>Votre Rendez est bien enregistre  nous allons vous contacter au plus tot possible </p>
      <a href="index.php">Acceuil</a><br>
      <a href="index.php?action=deconnexion">Deconnexion</a>
  

  </div>
  </body>