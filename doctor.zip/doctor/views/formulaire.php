
<!DOCTYPE html>
<html lang="en"> 
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="views/form.css">
    <link rel="shortcut icon" href="views/img/dent.png">
	<title>Formulaire</title>
<div class="container">
</head>
<body>
    <form  action="" method="post">
      <p>Bienvenue</p>
      <input type="email" placeholder="Enter your email" name="email"><span class="Err"><?= $erreur["email"] ?? "" ?> </span><br>
      <input type="password" placeholder="Enter your password" name="password"><span class="Err"><?= $erreur["password"] ?? "" ?> </span><br>
      <a href="#">Mot de passe oublié</a><br>
      <input type="submit" value="Connexion"><br>
    
      <a href="index.php?action=inscrire&route=<?=$_GET["route"]??""?>">Inscrivez-vous</a>
      
    </form>
  
    <div class="drop drop-1"></div>
    <div class="drop drop-2"></div>
    <div class="drop drop-3"></div>
    <div class="drop drop-4"></div>
    <div class="drop drop-5"></div>
  </div>
  </body>