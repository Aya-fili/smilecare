
<!DOCTYPE html>
<html lang="en"> 
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="views/form.css">
    <link rel="shortcut icon" href="views/img/dent.png">
	<title>Formulaire</title>
<div class="container">
</head>
<body>
    <form action="" method="post"  >
      <p>Bienvenue</p>
      <input name="date" type="date"  class="date"><span class="Err"><?= $erreur["date"] ?? "" ?></span>
      <input placeholder="entrer l'horaire souhaité" name="time" type="time"  class="horaire"><span class="Err"><?= $erreur["prenom"] ?? "" ?> </span><br>
      <input type="submit" value="valider" onclick="myFunction()" ><br>


      <input type="reset" value="Annuler"><br>
      <a href="index.php">Acceuil</a>
    </form>
  
    <div class="drop drop-1"></div>
    <div class="drop drop-2"></div>
    <div class="drop drop-3"></div>
    <div class="drop drop-4"></div>
    <div class="drop drop-5"></div>
  </div>
  </body>