<?php

include("Model.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require ('phpmailer\phpmailer\src\Exception.php');
require ('phpmailer\phpmailer\src\PHPMailer.php');
require ('phpmailer\phpmailer\src\SMTP.php');
function index(){
	require ("views/mypage.php");
	//afficher("mypage.php");
}
function authentifier(){
	if ($_SERVER["REQUEST_METHOD"]=="POST") {	
		$email = $_POST["email"];
		$pas= $_POST["password"];			
		if(empty($email))    $erreur["email"] ="L'e-mail ne peut être vide !..."   ;
		//elseif(substr(strtolower($email),-10,10)!="@gmail.com")    $erreur["email"] ="Utilisez un mail valide !..."   ;
		if(empty($pas))    $erreur["password"] ="Le mot de passe ne peut être vide !..."   ;
		if (!isset($erreur)) {
		if(validemailpass($email,$pas)){
	
		$_SESSION["user"]=$email;}
		
		if(!isset($_GET["route"])){
			header ("location:index.php?action=index");	
		}else{
			header ("location:index.php?action=rendez");	

		}
	}
	}
		//si l'user n'est pas authentifié donc on doit l'afficher une message d'erreur
		//throw new Exception("Impossible de se connecter veuillez !si vous n'avez pas de compte vous pouvez s'inscrire");
		
	
		$data =["email" => $email ?? "",
				"password" =>  $pas ?? "" ,
				"erreur"=> $erreur ?? ""
			   ];
		afficher ("formulaire.php",$data);
}


function inscrire(){
	
	if ($_SERVER["REQUEST_METHOD"]=="POST") {	
		$email = $_POST["email"];
		$password = $_POST["password"];	
		$prenom = $_POST["prenom"];
		$nom = $_POST["nom"];
		$telephone = $_POST["telephone"];

		if(empty($email))    $erreur["email"] ="L'e-mail ne peut être vide !..."   ;
		if(substr(strtolower($email),-10,10)!="@gmail.com")    $erreur["email"] ="Utilisez un mail valide !..."   ;
		if(empty($password))    $erreur["password"] ="Le mot de passe ne peut être vide !..."   ;
		if(empty($prenom))    $erreur["prenom"] ="Le prenom ne peut être vide !..."   ;
		if(empty($nom))    $erreur["nom"] ="Le nom ne peut être vide !..."   ;
		if(empty($telephone))    $erreur["telephone"] ="Le telephone ne peut être vide !..."   ;
		if (!isset($erreur)) {									
		           insertion($email,$nom,$prenom,$password,$telephone);//dans le model qui va permet d'ajouter un new user
				   $_SESSION["user"]=$email;
			if (empty($_GET["route"])){
				header ("location:index.php");	
			}else{
			header ("location:index.php?action=rendez");	
			}
		}
		
	}

		$data =["email" => $email  ?? "" ,
				"password" => $password  ?? "" ,
				"nom" => $nom  ?? "" ,
				"prenom" => $prenom  ?? "" ,
				"telephone" => $telephone  ?? "" ,
				"erreur"=> $erreur ?? ""
			   ];
		afficher ("Ajouter.php",$data);
}


function rendez(){ //l'action de rendez vous
	accessControl();	
	if ($_SERVER["REQUEST_METHOD"]=="POST") {	
	$dat=$_POST["date"];
	$tim=$_POST["time"];
	//valider les champs du formulaire		
	if(empty($dat) or $dat < Date("Y-m-d H:i:s")) $erreur["date"] ="Date de réservation invalide !..."   ;
	$dateTime = DateTime::createFromFormat('H:i', $tim);

// Définit les intervalles de temps souhaités
$startInterval1 = DateTime::createFromFormat('H:i', '09:00');
$endInterval1 = DateTime::createFromFormat('H:i', '12:30');
$startInterval2 = DateTime::createFromFormat('H:i', '14:00');
$endInterval2 = DateTime::createFromFormat('H:i', '16:30');
// Effectue les comparaisons
$isInInterval1 = $dateTime >= $startInterval1 && $dateTime <= $endInterval1;
$isInInterval2 = $dateTime >= $startInterval2 && $dateTime <= $endInterval2;

// Vérifie si le temps est dans l'un des deux intervalles
if (!($isInInterval1 || $isInInterval2)) {
$erreur["date"] ="Date de réservation invalide !..." ;}
	$id=$_GET["id"];
							
	if (!isset($erreur)) {		
	
		$user=$_SESSION["user"];#pour acceder aux infos de personne connecte
		$tabl=dataconnecte($user);
		$tabl2=docconnecte($id);

		$to= "aya.fili@usmba.ac.ma";//email de docteur 
		$subject = "demande d'un rendez vous" ;
		$message ="je suis ".$tabl["Prenom"]." ".$tabl["Nom"]." je viens de prendre un rendez-vous avec ".$tabl2["prenom"]." ".$tabl2["nom"]." dans la date ".$dat. " à ".$tim ;  
			
	sendEmail($to,$subject,$message);
	validation();
		
	}

}
$data =["erreur"      => $erreur ?? ""];
afficher("rendezvous.php", $data);
}

function validation(){
	header ("location:index.php?action=index");	
	afficher("validation.php");
}
	
function deconnexion() {
	session_destroy();
	header("location:index.php");
}
function sendEmail($to, $subject, $body) {
	$mail = new PHPMailer(true);

	try {
		// Set mailer to use SMTP
		$mail->isSMTP();
	
		// Specify SMTP server
		$mail->Host = 'smtp.gmail.com';
	
		// Specify SMTP username and password
		$mail->Username = 'aya5fili@gmail.com';
		$mail->Password = 'iojwbxbfyqdakubk';
	
		// Enable SMTP authentication
		$mail->SMTPAuth = true;
	
		// Enable TLS encryption, `ssl` also accepted
		$mail->SMTPSecure = 'ssl';
	
		// Port for SMTP
		$mail->Port = 465;
	
		// Set the 'From' email address
		$mail->setFrom('aya5fili@gmail.com');
	
		// Set the 'To' email address(es)
		$mail->addAddress($to);
		$mail->isHTML(true);
		// Set email subject and body
		$mail->Subject = 'From : SmileCare Reservation System ';
		$mail->Body    = $body;
	
		// Send the email
		$mail->send();
	
		echo 'Email sent successfully!';
	} catch (Exception $e) {
		echo 'Email could not be sent. Error: ', $mail->ErrorInfo;
	}
}